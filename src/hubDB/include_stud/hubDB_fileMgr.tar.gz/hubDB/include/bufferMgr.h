#ifndef _BUFFERMGR_H_
#define _BUFFERMGR_H_

#include <global.h>
#include <fileMgr.h>

class BufferMgr
{

  public:
    BufferMgr(int frameCount=MAXPOOLSIZE);
    ~BufferMgr();

  private:
  	FileMgr * fileMgr;

};

#endif // _BUFFERMGR_H_

