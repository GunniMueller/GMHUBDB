#ifndef _INDEXMGR_H_
#define _INDEXMGR_H_

#include <global.h>
#include <bufferMgr.h> 

#ifndef _BTREE_H_
typedef void *  BTreePtr;
#endif

class IndexMgr
{
 private:
  /* der Buffer-Manager */
  BufferMgr & bufferMgr;
  const int maxOpenIdx;
  int lastUnUsed;
  BTreePtr * btrees;
 	
 public:        

  IndexMgr(BufferMgr & buf, const int max = MAXOPENINDEXES);
  ~IndexMgr();

};

#endif /* _INDEXMGR_H_ */

