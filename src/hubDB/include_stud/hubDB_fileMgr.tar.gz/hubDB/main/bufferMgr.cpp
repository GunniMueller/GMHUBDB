#include <global.h>
#include <bufferMgr.h>

BufferMgr::BufferMgr(int frameCount):
 fileMgr()
{
  fileMgr = new FileMgr;
}

BufferMgr::~BufferMgr()
{
  delete fileMgr;
}
