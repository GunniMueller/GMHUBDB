#include <bufferMgr.h>

int main()
{
  bool details=true;
  BufferMgr::test(details);
  return 0;
}
