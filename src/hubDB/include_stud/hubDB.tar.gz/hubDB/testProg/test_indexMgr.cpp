#include "indexMgr.h"

int main() 
{
  bool details=true;
  IndexMgr::test(details);
  return 0;
}

