#include <fileMgr.h>

int main()
{
  bool details=true;
  FileMgr::test(details);
  return 0;
}
