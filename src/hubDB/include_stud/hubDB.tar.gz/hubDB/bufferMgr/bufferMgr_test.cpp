#include <bufferMgr.h>

void BufferMgr::test(bool details) {
	BufferMgr * bMgr = new BufferMgr(4);
	FileNo fno1, fno2;
	PageID pageid;
	BACB *bacb1, *bacb2, *bacb3, *bacb4, *bacb5;

	// Dateien anlegen
	if (details) cout << "- Dateien 'index1.dat' und 'index2.dat' anlegen:" << endl;
	try {
		bMgr->createFile("index1.dat", fno1);
		bMgr->createFile("index2.dat", fno2);
		OKAY(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		FAILED(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// Seite (fno1, 1) mittels fixNewPage() anlegen
	if (details) cout << "- Seite ('index1.dat', 1) mittels fixNewPage() anlegen:" << endl;
	pageid.setFileNo(fno1);
	pageid.setPageNo(1);
	try {
		bacb1 = bMgr->fixNewPage(pageid, Lock(2));
		OKAY(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		FAILED(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// Seite (fno1, 3) mittels fixNewPage() anlegen
	if (details) cout << "- Seite ('index1.dat', 3) mittels fixNewPage() anlegen:" << endl;
	pageid.setFileNo(fno1);
	pageid.setPageNo(3);
	try {
		bacb2 = bMgr->fixNewPage(pageid, Lock(2));
		OKAY(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		FAILED(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// Seite (fno1, 10) mittels fixNewPage() anlegen
	if (details) cout << "- Seite ('index1.dat', 10) mittels fixNewPage() anlegen:" << endl;
	pageid.setFileNo(fno1);
	pageid.setPageNo(10);
	try {
		bacb3 = bMgr->fixNewPage(pageid, Lock(2));
		OKAY(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		FAILED(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// Seite (fno2, 10) mittels fixNewPage() anlegen
	if (details) cout << "- Seite ('index2.dat', 10) mittels fixNewPage() anlegen:" << endl;
	pageid.setFileNo(fno2);
	pageid.setPageNo(10);
	try {
		bacb4 = bMgr->fixNewPage(pageid, Lock(2));
		OKAY(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		FAILED(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// ERROR: neue Seite in vollem Bufferpool anlegen
	if (details) cout << "- ERROR: neue Seite in vollem Bufferpool (frameCount=4) anlegen:" << endl;
	pageid.setFileNo(fno1);
	pageid.setPageNo(99);
	try {
		bMgr->fixNewPage(pageid, Lock(2));
		FAILED(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		OKAY(cout);
	}

		// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// Inhalte in die Seiten schreiben
	if (details) cout << "- Inhalte in alle vier Seiten schreiben:" << endl;
	try {
		strcpy(bacb1->getDataPtr(), "- Seite 1.1 -");
		bacb1->setModified();
		strcpy(bacb2->getDataPtr(), "- Seite 1.3 -");
		bacb2->setModified();
		strcpy(bacb3->getDataPtr(), "- Seite 1.10 -");
		bacb3->setModified();
		strcpy(bacb4->getDataPtr(), "- Seite 2.10 -");
		bacb4->setModified();
		OKAY(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		FAILED(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// ERROR: Sperrkonflikt LOCK_S vs. LOCK_X auf einer Seite
	if (details) cout << "- ERROR: Sperrkonflikt LOCK_S vs. LOCK_X auf einer Seite:" << endl;
	pageid.setFileNo(fno1);
	pageid.setPageNo(3);
	try {
		bMgr->fixPage(pageid, Lock(1));
		FAILED(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		OKAY(cout);
	}

		// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// ERROR: Sperrkonflikt LOCK_X vs. LOCK_X auf einer Seite
	if (details) cout << "- ERROR: Sperrkonflikt LOCK_X vs. LOCK_X auf einer Seite:" << endl;
	pageid.setFileNo(fno1);
	pageid.setPageNo(3);
	try {
		bMgr->fixPage(pageid, Lock(2));
		FAILED(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		OKAY(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// Fixierung von Seiten (fno1, 3), (fno1, 10) und (fno2, 10) l�sen
	if (details) cout << "- Fixierung von Seiten ('index1.dat', 3), ('index1.dat', 10) und ('index2.dat', 10) l�sen:" << endl;
	try {
		bMgr->unfixPage(bacb2);
		bMgr->unfixPage(bacb3);
		bMgr->unfixPage(bacb4);
		OKAY(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		FAILED(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// Seite (fno2, 13) mittels fixNewPage() anlegen
	if (details) cout << "- Seite ('index2.dat', 13) mittels fixNewPage() anlegen:" << endl;
	pageid.setFileNo(fno2);
	pageid.setPageNo(13);
	try {
		bacb2 = bMgr->fixNewPage(pageid, Lock(2));
		OKAY(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		FAILED(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// Seite (fno2, 8) mittels fixNewPage() anlegen
	if (details) cout << "- Seite ('index2.dat', 8) mittels fixNewPage() anlegen:" << endl;
	pageid.setFileNo(fno2);
	pageid.setPageNo(8);
	try {
		bacb3 = bMgr->fixNewPage(pageid, Lock(2));
		OKAY(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		FAILED(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// ERROR: Seite mittels fixNewPage() mit LOCK_S anlegen
	if (details) cout << "- ERROR: Seite mittels fixNewPage() mit LOCK_S anlegen:" << endl;
	pageid.setFileNo(fno2);
	pageid.setPageNo(100);
	try {
		bMgr->fixNewPage(pageid, Lock(1));
		FAILED(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		OKAY(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// Inhalte in Seiten schreiben
	if (details) cout << "- Inhalte der Seiten ('index2.dat', 13) und ('index2.dat', 8) schreiben:" << endl;
	try {
		strcpy(bacb2->getDataPtr(), "- Seite 2.13 -");
		bacb2->setModified();
		strcpy(bacb3->getDataPtr(), "- Seite 2.8 -");
		bacb3->setModified();
		OKAY(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		FAILED(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// Inhalt der Seite (fno2, 8) mit BufferMgr::flush in die Datei schreiben
	if (details) cout << "- Inhalt der Seite ('index2.dat', 8) mit BufferMgr::flush() in die Datei schreiben:" << endl;
	try {
		bMgr->flushPage(bacb3);
		OKAY(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		FAILED(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// Inhalt einer nicht modifizierten Seite mit BufferMgr::flush in die Datei schreiben
	if (details) cout << "- ERROR: Inhalt einer nicht modifizierten Seite mit BufferMgr::flush() schreiben:" << endl;
	try {
		bMgr->flushPage(bacb3);
		FAILED(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		OKAY(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// Fixierungen von den Seiten ('index1.dat', 1), ('index2.dat', 13) und ('index2.dat', 8) l�sen
	if (details) cout << "- Fixierungen von den Seiten ('index1.dat', 1), ('index2.dat', 13) und ('index2.dat', 8) l�sen:" << endl;
	try {
		bMgr->unfixPage(bacb1);
		bMgr->unfixPage(bacb2);
		bMgr->unfixPage(bacb3);
		OKAY(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		FAILED(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// Seite (fno1, 3) mittels fixPage() laden
	if (details) cout << "- Seite ('index1.dat', 3) mittels fixPage() laden:" << endl;
	pageid.setFileNo(fno1);
	pageid.setPageNo(3);
	try {
		bacb1 = bMgr->fixPage(pageid, Lock(1));
		OKAY(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		FAILED(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// Seite (fno1, 10) mittels fixPage() laden
	if (details) cout << "- Seite ('index1.dat', 10) mittels fixPage() laden:" << endl;
	pageid.setFileNo(fno1);
	pageid.setPageNo(10);
	try {
		bacb2 = bMgr->fixPage(pageid, Lock(1));
		OKAY(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		FAILED(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// Seite (fno1, 3) mittels fixPage() erneut laden
	if (details) cout << "- Seite ('index1.dat', 3) mittels fixPage() nochmals laden:" << endl;
	pageid.setFileNo(fno1);
	pageid.setPageNo(3);
	try {
		bacb5 = bMgr->fixPage(pageid, Lock(1));
		OKAY(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		FAILED(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// Seite (fno1, 1) mittels fixPage() laden
	if (details) cout << "- Seite ('index1.dat', 1) mittels fixPage() laden:" << endl;
	pageid.setFileNo(fno1);
	pageid.setPageNo(1);
	try {
		bacb3 = bMgr->fixPage(pageid, Lock(1));
		OKAY(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		FAILED(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// Seite (fno2, 8) mittels fixPage() laden
	if (details) cout << "- Seite ('index2.dat', 8) mittels fixPage() laden:" << endl;
	pageid.setFileNo(fno2);
	pageid.setPageNo(8);
	try {
		bacb4 = bMgr->fixPage(pageid, Lock(2));
		OKAY(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		FAILED(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// Inhalt in die Seite schreiben
	if (details) cout << "- Inhalt in die Seite ('index2.dat', 8) schreiben:" << endl;
	try {
		strcpy(bacb4->getDataPtr(), "# Seite 2.8 #");
		bacb4->setModified();
		OKAY(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		FAILED(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// Fixierungen von den Seiten ('index1.dat', 1), ('index1.dat', 3), ('index1.dat', 10)
	// und ('index2.dat', 8) l�sen
	if (details) cout << "- Fixierungen von den Seiten ('index1.dat', 3), ('index1.dat', 10), ('index1.dat', 1)"
					  << endl << "  und ('index2.dat', 8) l�sen:" << endl;
	try {
		bMgr->unfixPage(bacb1);
		bMgr->unfixPage(bacb2);
		bMgr->unfixPage(bacb3);
		bMgr->unfixPage(bacb4);
		OKAY(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		FAILED(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	if (details) cout << "- ERROR: Datei 'index1.dat' schliessen, obwohl ('index1.dat', 3) noch fixiert:" << endl;
	try {
		bMgr->closeFile(fno1);
		FAILED(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		OKAY(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// Fixierungen von der Seite ('index1.dat', 3) l�sen
	if (details) cout << "- Fixierungen von der Seite ('index1.dat', 3) l�sen:" << endl;
	try {
		bMgr->unfixPage(bacb5);
		OKAY(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		FAILED(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// Dateien schliessen
	if (details) cout << "- Dateien 'index1.dat' und 'index2.dat' schliessen:" << endl;
	try {
		bMgr->closeFile(fno1);
		bMgr->closeFile(fno2);
		OKAY(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		FAILED(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}

	// Dateien l�schen
	if (details) cout << "- Dateien 'index1.dat' und 'index2.dat' loeschen:" << endl;
	try {
		bMgr->dropFile("index1.dat");
		bMgr->dropFile("index2.dat");
		OKAY(cout);
	}
	catch (ErrorObj e) {
		cout << e;
		FAILED(cout);
	}

	// Ausgabe des Bufferpools
	if (details) {
		cout << endl << *bMgr
		     << "-------------------------------------------------------------------"
		     << endl << endl;
	}
}