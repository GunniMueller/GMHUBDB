#include <syscat.h>

void SysCat::listTables(const string& directory, list<TableInfo>& tableInfoList)
{
}
