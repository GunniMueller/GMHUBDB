#include <global.h>
#include <execEngine.h>

int yyparse();
void yy_scan_string(const char *);

extern ExecEngine * engine;
extern bool _USE_EXEC_ENGINE;

int parse_execFromString(char * str)
{
  yy_scan_string(str);
  cout << "\\> ";
  return yyparse();
}

int parse_execFromFile()
{
  cout << "\\> ";
  return yyparse();
}


int main()
{
  int rc =0;
  _USE_EXEC_ENGINE=true;
  engine = new ExecEngine;
  rc = parse_execFromFile();
  delete engine;
  return rc;
}

