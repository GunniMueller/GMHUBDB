#ifndef _EXECENGINE_H_
#define _EXECENGINE_H_

#include <map>
#include <list>

#include <global.h>
#include <bufferMgr.h>
#include <indexMgr.h>
#include <errorObj.h>
#include <syscat.h>

const int EXEC_ERROR_UNKNOWN = 0;
const int EXEC_EXISTING_DB_CONNECTION = 1;
const int EXEC_DB_DIR_NOE = 2;
const int EXEC_DB_DIR_NR = 3;
const int EXEC_DB_DIR_NW = 4;
const int EXEC_NO_CONNECTION = 5;
const int EXEC_INVALID_ID = 6;
const int EXEC_INVALID_NAME = 7;

typedef map<string,FileNo> Str2FileNoType;

class ExecEngine {

 // Auflistung der einzelnen Methoden. Jeweils eine Methode pro Kommando,
 // welches der Parser erkenen kann.
 public:

  ExecEngine();
  ~ExecEngine();

  /*
   * F�r die Implemetierung von IMPORT und EXPORT, sowie f�r die Ein-/Ausgabe
   * wird die Klasse ostream ben�tigt.
   */

  friend ostream & operator<<(ostream & stream,ExecEngine& engine);

  /*
   * CONNECT <directory>: Baut eine "virtuelle" Verbindung zu einer
   * Datenbank auf. Die Datenbanken werden in Form von Verzeichnissen des
   * Dateisystems repr�sentiert. Jede Tabelle der Datenbank entspricht einer
   * Datei im angegebenen Verzeichnis mit fester Extension (.tab)
   */

  void connect(string directory);

  /*
   * DISCONNECT: Beendet die Verbindung zu einer Datenbank. Es erfolgt ein
   * R�cksetzen in den initialen Zustand.
   */

  void disconnect();

  /*
   * LIST TABLES: Entspricht einer Anfrage an den Systemkatalog zum Auflisten
   * s�mtlicher Tabellen in dem bei CONNECT angegebenen Verzeichnis (alle
   * Dateien mit der Endung .TAB werden ausgegeben, zusammen mit dem Datum
   * ihrer Erstellung, dem Datum der letzten Modifikation sowie der Anzahl
   * an belegten Bl�cken.
   */

  void listTables();

  /*
   * CREATE TABLE <table name>: Erstellt eine Tabelle mit dem angegebenen
   * Namen, d.h. es wird eine Datei mit angegebenen Namen und der Endung .TAB
   * im Datenbankverzeichnis angelegt.
   */

  void createTable(string tableName);

  /*
   * DROP TABLE <table name>: L�scht die Tabelle mit dem angegeben Namen,d.h.
   * die entsprechende Datei aus dem Datenbankverzeichnis.
   */

  void dropTable(string tableName);

  /*
   * INSERT INTO <table name> VALUES <id, name>: F�gt ein Tupel mit den
   * angegebenen Werten in die spezifizierte Tabelle ein.
   */

  void insertTuple(string tableName, int id, string name);

  /*
   * DELETE FROM <table name> WHERE ID = <id>: L�scht das Tupel mit der
   * angegebenen ID aus der spezifizierten Tabelle.
   */

  void deleteTuple(string tableName, int id);

  /*
   * SELECT * FROM <table name>: Listet s�mtliche Tupel der genannten Tabelle
   * auf.
   */

  void selectAll(string tableName);

  /*
   * SELECT * FROM <table name> WHERE ID = <id>: Gibt nur das Tupel mit
   * der angegebenen ID aus.
   */

  void selectWhere(string tableName, int id);

  /*
   * IMPORT FROM <filename> INTO <table name>: Laed die Tupel der angegebenen
   * Datei in die spezifizierte Tabelle. Die Tupel werden an die Tabelle
   * angef�gt. Die Datei enth�lt pro Zeile eine ID und einen Namen, die
   * jeweils durch einen Tabulator voneinander getrennt sind.
   */

  void importFrom(string fileName, string tableName);

  /*
   * EXPORT TO <filename> FROM <table name>: Exportiert die spezifizierte
   * Tabelle in eine Datei mit dem angegebenen Namen. Jedes Tupel wird in eine
   * Zeile geschrieben, wobei ID und NAME durch einen Tabulator getrennt sind.
   */

  void exportTo(string fileName, string tableName);

  /*
   * EXIT/QUIT: Beendet das Program. Zuvor wird DISCONNECT augerufen, falls
   * aktuell eine Verbindung zu einer Datenbank besteht.
   */

  void quit();


  //
  // Private Variablen der Execution Engine
  //

 protected:

  BufferMgr * bufferMgr;
  IndexMgr * indexMgr;
  SysCat sysCat;

  string _directory;
  bool _isConnected;

  // Liste zur Verwaltung offener Dateien
  Str2FileNoType fileNoList;
  /*
   * Ausgabe von Fehlermeldungen der Execution Engine
   */

  void errorMsg(MinorErrorCode minorError);
  void errorMsg(ErrorObj& errorObj);
  void errorMsg(ErrorObj::MajorErrorCode majorError, MinorErrorCode minorError, string errorMessage);

  /*
   * Ausgabe eines Tupels bzw. einer gesamten Tabelle auf einen
   * uebergebenen Stream
   */

  void outputTuple(Tuple& tuple, ostream & out);
  int outputTable(string tableName, ostream & out);

  /*
   * Funktion zum Erzeugen des zugehoerigen Dateinamens fuer einen gegebenen
   * Tabellennamen.
   */

  string tableName2fileName(string& tableName);

  /*
   * Protokollierung der geoffneten Dateien
   */

  void openFile(string & fileName,FileNo & fileNo);
  void closeFile(string & fileName);
  void initFileList();
  
};

#endif /* _EXECENGINE_H_ */



  
