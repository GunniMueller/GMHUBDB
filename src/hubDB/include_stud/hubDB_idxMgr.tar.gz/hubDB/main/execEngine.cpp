#include <execEngine.h>
#include <indexMgr.h>
#include <bufferMgr.h>

ExecEngine::ExecEngine():
  bufferMgr(NULL),
  indexMgr(NULL)
{
  bufferMgr = new BufferMgr();
  indexMgr = new IndexMgr(*bufferMgr);
  _isConnected = false;
}

ExecEngine::~ExecEngine()
{
  if(_isConnected == true){
    disconnect();
  }
  delete indexMgr;
  delete bufferMgr;
};

