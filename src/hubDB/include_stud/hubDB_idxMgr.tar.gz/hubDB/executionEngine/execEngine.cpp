#include <execEngine.h>
#include <indexMgr.h>
#include <bufferMgr.h>
#include <errorObj.h>
#include <unistd.h>
#include <time.h>

//
// CONSTRUCTOR
//

/*
 * Es wird ein Pointer auf den Index-Manager sowie auf den Buffer-Manager
 * und den Systemkatalog benoetigt. Zusaetzlich wird das conected-Flag auf
 * false gesetzt.
 */
/*
ExecEngine::ExecEngine():
  bufferMgr(NULL),
  indexMgr(NULL)
{
  bufferMgr = new BufferMgr();
  indexMgr = new IndexMgr(*bufferMgr);
  _isConnected = false;
}

ExecEngine::~ExecEngine()
{
  if(_isConnected == true){
    disconnect();
  }
  delete indexMgr;
  delete bufferMgr;
};
*/
//
// PUBLIC
//

ostream & operator<<(ostream & stream,ExecEngine& engine)
{
  stream<<"BufferMgr: "<<hex<<engine.bufferMgr<<dec<<endl;
  stream<<*engine.bufferMgr<<endl;
  stream<<"IndexMgr: "<<hex<<engine.bufferMgr<<dec<<endl;
  stream<<*engine.indexMgr<<endl;
  stream<<"Directory: "<<engine._directory<<endl;
  stream<<"IsConnected: "<<boolalpha<<engine._isConnected<<dec<<endl;
  Str2FileNoType::iterator it=engine.fileNoList.begin();
  stream<<"FileNoList length: "<<engine.fileNoList.size()<<endl;
  while(it!=engine.fileNoList.end()){
    stream << "FileName: "<<(*it).first<<" FileNo: "<<(*it).second<<endl;
    ++it;
  }
  return stream;
}

/*
 * Die Routine �berpr�ft die G�ltigkeit des �bergebenen Verzeichnisnamen, d.h.
 * es wird gepr�ft, ob das Verzeichnis existiert. Der Verzeichnisname wird
 * sich gemerkt, sowie das connected-Flag gesetzt. Wirft eine Fehlermeldung,
 * wenn bereits eine Verbindung zu einer (anderen) "Datenbank" existiert. Es
 * kann immer nur eine Verbindung aufgebaut sein, selbst wenn es sich um die
 * gleiche Datenbank handelt.
 */

void ExecEngine::connect(string directory) {

  if (_isConnected == true) {
    errorMsg(EXEC_EXISTING_DB_CONNECTION);
    return;
  }

  // Testen, ob das angegebene Verzeichnis existiert, d.h. ge�ffnet werden
  // kann. Wenn nicht, wird eine Exception geworfen.

  if (access(directory.c_str(), F_OK) < 0) {
    errorMsg(EXEC_DB_DIR_NOE);
    return;
  }

  if (access(directory.c_str(), R_OK) < 0) {
    errorMsg(EXEC_DB_DIR_NR);
    return;
  }

  if (access(directory.c_str(), W_OK) < 0) {
    errorMsg(EXEC_DB_DIR_NW);
    return;
  }

  // Das angegebene Verzeichnis existiert, d.h. die Verbindung ist aufgebaut
  // Es wird sichergestellt, dass _directory mit einem "slash" endet
  unsigned int pos = directory.rfind("/", directory.length() - 1);
  if(pos != string::npos) {
    if (pos == directory.length() - 1) {
      _directory = directory;
    } else {
      _directory = directory + "/";
    }
  } else {
    _directory = directory + "/";
  }
  _isConnected = true;

  //Initialisiert die Liste zur Protokollierung geoeffneter Dateien
  initFileList();
}

/*
 * Beim Disconnect wird das System in einen initialen Zustand versetzt. Hier
 * werden u.a. die Buffer geleert und die geoeffneten Dateien geschlossen.
 * Die Routine ruft dazu die disconnect-Methode des Index-Manager auf, der den
 * Aufruf dann weiter nach unten durchreicht. Sollte aktuell keine Verbindung
 * zu einer Datenbank bestehen, wird eine Fehlermeldung ausgegeben.
 */

void ExecEngine::disconnect() {

  // Die Aktion ist nur moeglich, wenn eine Verindung zu einer Datenbank
  // existiert.
  if (_isConnected == false) {
    errorMsg(EXEC_NO_CONNECTION);
    return;
  }

  try {
    Str2FileNoType::iterator it = fileNoList.begin();
    if(it!=fileNoList.end()){
      indexMgr->closeIndex((*it).second);
      ++it;
    }
    indexMgr->disconnect();
  } catch(ErrorObj e) {
    errorMsg(e);
  }

  _isConnected = false;
}

/* Erstellt eine Tabelle mit dem angegebenen Namen durch Aufruf der
 * entsprechenden Methode des Index-Manager. Zuvor wird der Tabellenname
 * durch Vorstellen des Datenbankverzeichnisses und der Standard-Endung in
 * einen Dateinamen umgewandelt. Es muss eine Fehlermeldung ausgegeben werden,
 * falls die resultierende Datei bereits existiert.  Sie darf nicht als leere
 * Datei ueberschrieben werden.
 */

void ExecEngine::createTable(string tableName) {

  // Die Aktion ist nur moeglich, wenn eine Verindung zu einer Datenbank
  // existiert.
  if (_isConnected == false) {
    errorMsg(EXEC_NO_CONNECTION);
    return;
  }

  string tableFilename = tableName2fileName(tableName);

  try {
    FileNo fileNo;
    // Erzeugt die Datei. Die neu erzeugte Datei ist gleichzeitig geoffnet
    // worden. Dies wird deshalb zusaetzlich protokolliert
    indexMgr->createIndex(tableFilename, fileNo);

    pair<string,int> val;
    val.first = tableFilename;
    val.second = fileNo;
    fileNoList.insert(val);

  } catch (ErrorObj e) {
    errorMsg(e);
  }
}

/* Loescht die angegeben Tabelle bzw. die entsprechende Datei, falls diese
 * existiert. Durch Aufruf der entsprechenden Routine des Index-Managers
 * wird sichergestellt, dass unterliegende Module vom Loeschen der Tabelle
 * erfahren und ggf. aufraeumen koennen.
 */

void ExecEngine::dropTable(string tableName) {

  // Die Aktion ist nur moeglich, wenn eine Verindung zu einer Datenbank
  // existiert.
  if (_isConnected == false) {
    errorMsg(EXEC_NO_CONNECTION);
    return;
  }

  string tableFilename = tableName2fileName(tableName);

  // Die Datei muss entsprechent der Anzahl der zuvor ausgefuehrten open()-
  // Aufrufe geschlossen werden, damit der FileManager nicht "meckert"
  closeFile(tableFilename);

  try {
    indexMgr->dropIndex(tableFilename);
  } catch (ErrorObj e) {
    errorMsg(e);
  }
}

/* Fuegt ein Tupel in die angegebene Tabelle ein. Sollte bereits ein Tupel
 * mit der entsprechenden ID in der Tabelle existieren, so wird eine
 * Fehlermeldung ausgegeben. Das Einfuegen erfolgt durch Aufruf der Methode
 * insert() des Index-Manager. Dieser sollte auch die entsprechende Exception
 * werfen, falls das Tupel bzw. die ID bereits existiert.
 */

void ExecEngine::insertTuple(string tableName, int id, string name) {

  // Die Aktion ist nur moeglich, wenn eine Verindung zu einer Datenbank
  // existiert.
  if (_isConnected == false) {
    errorMsg(EXEC_NO_CONNECTION);
    return;
  }

  string tableFilename = tableName2fileName(tableName);

  // Ueberpruefe die uebergebenen Werte. Bei den IDs muss es sich um positive
  // Integerwerte groesser 0 handeln, die Namen duerfen nicht laenger als 28
  // Zeichen sein.
  if (id <= 0) {
    errorMsg(EXEC_INVALID_ID);
    return;
  }
  if (name.length() >= NAME_LENGTH ) {
    errorMsg(EXEC_INVALID_NAME);
    return;
  }

  Tuple tuple = Tuple(id, (char *)name.c_str());

  try {
    FileNo fileNo;
    // Protokolliert die geoffnete Dateien
    openFile(tableFilename,fileNo);
    if(indexMgr->insert(fileNo, tuple)==true){
      cout << 1 << " record(s) inserted" << endl;
    }else{
      cout << 0 << " record(s) inserted" << endl;
    }

  } catch (ErrorObj e) {
    errorMsg(e);
  }
}

/* Loescht das Tupel mit der angegebenen ID. Sollte dieses Tupel nicht
 * existieren, so ist dies nicht als Fehler anzusehen. Es wird am Ende eine
 * Statusmeldung ausgegeben ind der die Anzahl der geloeschten Tupel (0 oder 1)
 * steht. Das Loeschen erfolgt durch direkten Aufruf der entsprechenden
 * Methode des Index-Manager.
 */

void ExecEngine::deleteTuple(string tableName, int id) {

  // Die Aktion ist nur moeglich, wenn eine Verindung zu einer Datenbank
  // existiert.
  if (_isConnected == false) {
    errorMsg(EXEC_NO_CONNECTION);
    return;
  }

  string tableFilename = tableName2fileName(tableName);

  // Ueberpruefe die uebergebenen Werte. Bei den IDs muss es sich um positive
  // Integerwerte groesser 0 handeln.
  if (id <= 0) {
    errorMsg(EXEC_INVALID_ID);
    return;
  }
  try {
    FileNo fileNo;
    // Protokolliert die geoffnete Dateien
    openFile(tableFilename,fileNo);
    if(indexMgr->remove(fileNo, &id)==true){
      cout << 1 << " record(s) deleted" << endl;
    }else{
      cout << 0 << " record(s) deleted" << endl;
    }
  } catch (ErrorObj e) {
    errorMsg(e);
  }
}

/* Es wird der gesamte Inhalt der Tabelle ausgegeben. Dabei wird ueber den
 * Buffer-Manager sequentiell die Datei gelesen und die Tupel aus der Block-
 * struktur extrahiert. Die Struktur der Bloecke entspricht der eines Knotens
 * des B-Baums.
 */

void ExecEngine::selectAll(string tableName) {
  int ret = outputTable(tableName, cout);
  if (ret >= 0) {
    cout << ret << " record(s) selected" << endl;
  }
}

/* Gibt das ueber seine ID spezifizierte Tupel aus, so es existiert. Wenn
 * nicht, wird eine entsprechende Statusmeldung ausgegeben. In diesem Fall
 * kann nun wieder auf den Methoden des Index-Manager aufgesetzt werden.
 */

void ExecEngine::selectWhere(string tableName, int id) {

  // Die Aktion ist nur moeglich, wenn eine Verindung zu einer Datenbank
  // existiert.
  if (_isConnected == false) {
    errorMsg(EXEC_NO_CONNECTION);
    return;
  }

  string tableFilename = tableName2fileName(tableName);

  // Ueberpruefe die uebergebenen Werte. Bei den IDs muss es sich um positive
  // Integerwerte groesser 0 handeln.
  if (id <= 0) {
    errorMsg(EXEC_INVALID_ID);
    return;
  }
  try {
    FileNo fileNo;
    // Protokolliert die geoffnete Dateien
    openFile(tableFilename,fileNo);
    Tuple* tuple = indexMgr->find(fileNo, &id);
    int cnt=0;
    if(tuple!=NULL){
      ++cnt;
      outputTuple(*(tuple), cout);
    }
    cout << cnt << " record(s) selected" << endl;
  } catch (ErrorObj e) {
    errorMsg(e);
  }
}

/* Es werden Tupel aus einer Datei geladen. Daei wird die Datei zeilenweise
 * gelesen. Jede Zeile entspricht einem Tupel. Das Format der Zeile ist fest
 * vorgegeben: Zunaechst kommt die ID, dann eine Tabulator und dann der Name.
 * Jede Zeile wird geparst und dann wird insert() aufgerufen.
 */

void ExecEngine::importFrom(string fileName, string tableName) {

  // Die Aktion ist nur moeglich, wenn eine Verindung zu einer Datenbank
  // existiert.
  if (_isConnected == false) {
    errorMsg(EXEC_NO_CONNECTION);
    return;
  }
  string tableFilename = tableName2fileName(tableName);
  try {
    FileNo fileNo;
    // Protokolliert die geoffnete Dateien
    openFile(tableFilename,fileNo);

    ifstream inFile(fileName.c_str());
    if(inFile.is_open()!=true){
      THROW_SYS_ERROR;
    }
    Tuple tuple(1,"");
    int cnt=0;
    while(inFile.eof()!=true){
      inFile >> tuple;
      if(inFile.eof()==true) break;
      if(indexMgr->insert(fileNo,tuple)==true) ++cnt;
    }
    inFile.close();
    cout << cnt << " record(s) imported" << endl;
  } catch (ErrorObj e) {
    errorMsg(e);
  }
}

/* Das Exportieren verhaelt sich aehnlich wie ein SELECT ALL. Es wird die Datei
 * sequentiell durchlaufen. Diesmal werden die Tupel allerdings nicht nach
 * STD-OUT gegeben, sondern in eine Datei. Das Format ist auch etwas anders, da
 * nun ja das vorgegebene Format der Datei <id><tab><name> eingehalten werden
 * muss.
 */

void ExecEngine::exportTo(string fileName, string tableName) {
  try{
    ofstream to(fileName.c_str());
    if (to.is_open()!=true) {
      THROW_SYS_ERROR;
    }
    int cnt=outputTable(tableName, to);
    cout << cnt << " record(s) exported" << endl;
  } catch (ErrorObj e) {
    errorMsg(e);
  }
}

/* Beim Beenden des Programms muss sichergestellt werden, dass zunaechst
 * eine evtl. noch bestehende Verbindung getrennt wird, so dass noch zu
 * schreibende Seiten auch auf den Sekundaerspeicher ausgelagert werden.
 */

void ExecEngine::quit() {
  if (_isConnected == true) {
    disconnect();
  }
}

//
// PRIVATE
//

/*
 * Methoden zur Ausgabe von Fehlermeldungen
 */

void ExecEngine::errorMsg(MinorErrorCode minorError) {
  switch(minorError) {
  case EXEC_EXISTING_DB_CONNECTION:
    errorMsg(ErrorObj::EXEC_ENGINE_ERROR, minorError, "There already exists a database connection");
    break;
  case EXEC_DB_DIR_NOE:
    errorMsg(ErrorObj::EXEC_ENGINE_ERROR, minorError, "The database directory does not exist");
    break;
  case EXEC_DB_DIR_NR:
    errorMsg(ErrorObj::EXEC_ENGINE_ERROR, minorError, "The database directory is not readable");
    break;
  case EXEC_DB_DIR_NW:
    errorMsg(ErrorObj::EXEC_ENGINE_ERROR, minorError, "The database directory is not writable");
    break;
  case EXEC_NO_CONNECTION:
    errorMsg(ErrorObj::EXEC_ENGINE_ERROR, minorError, "There is no connection to a database directory");
    break;
  case EXEC_INVALID_ID:
    errorMsg(ErrorObj::EXEC_ENGINE_ERROR, minorError, "The specified ID is invalid");
    break;
  case EXEC_INVALID_NAME:
    errorMsg(ErrorObj::EXEC_ENGINE_ERROR, minorError, "The specified NAME is invalid");
    break;
  default:
    errorMsg(ErrorObj::EXEC_ENGINE_ERROR, EXEC_ERROR_UNKNOWN, "Unknown error");
    break;
  }
}

void ExecEngine::errorMsg(ErrorObj& errorObj) {
  errorMsg(errorObj.getMajorError(), errorObj.getMinorError(), errorObj.getMinorErrorMsg());
}

void ExecEngine::errorMsg(ErrorObj::MajorErrorCode majorError, MinorErrorCode minorError, string errorMessage) {
  cout << "hubdb(" << majorError << ", " << minorError << ") Msg: " << errorMessage << endl;
}

/*
 * Ausgabe eines Tupels
 */

void ExecEngine::outputTuple(Tuple& tuple, ostream & out) {
  out << tuple.getId() << "\t" << tuple.getName() << endl;
}

/*
 * Ausgabe der gesamten Tabelle auf den uebergebenen Stream
 */

int ExecEngine::outputTable(string tableName, ostream & out) {

  // Die Aktion ist nur moeglich, wenn eine Verindung zu einer Datenbank
  // existiert.
  if (_isConnected == false) {
    errorMsg(EXEC_NO_CONNECTION);
    return -1;
  }

  string tableFilename = tableName2fileName(tableName);

  int tupleCount = 0;

  try {
    FileNo fileNo;
    // Protokolliert die geoffnete Dateien
    //    bufferMgr->openFile(tableFilename, fileNo);
    openFile(tableFilename,fileNo);

    // Sequentieller Durchlauf durch die Datei
    int pageCnt =  bufferMgr->getPageCount(fileNo);
    for(PageNo p = 1; (p < pageCnt); ++p) {
      PageID page(fileNo,p);
      BACB * bacb = bufferMgr->fixPage(page,LOCK_S);
      char * data = bacb->getDataPtr();
      char * ptr = data;
      int numT=*((int*)data);
      ptr+=sizeof(int);
      //next free Page
      ptr+=sizeof(PageNo);
      //less than all Page
      ptr+=sizeof(PageNo);
      for(int u=0;u<numT;++u){
	//tupel
	Tuple tmp = Tuple(ptr);
	// Ausgabe des aktuellen Tupel
	outputTuple(tmp, out);
	tupleCount++;
	//lower node
	ptr+=ENTRYSIZE;
      }
      bufferMgr->unfixPage(bacb);
    }
  } catch(ErrorObj e) {
    errorMsg(e);
  }
  return tupleCount;
}

/*
 * Funktion zum Erzeugen des zugehoerigen Dateinamens fuer einen gegebenen
 * Tabellennamen.
 */

string ExecEngine::tableName2fileName(string& tableName) {
  string tmp = "";
  for(int i=0;i<tableName.length();++i){
    tmp+=tolower(tableName.c_str()[i]);
  }
  tableName=tmp;
  return _directory + tableName + TABLEFILESUFFIX;
}

/*
 * Protokollierung der geoffneten Dateien
 */

  /*
   * Durchsuche die Liste der offenen Dateien. Wenn die gewuenschte Datei
   * bereits geoeffnet ist, gib ihre FileNo zurueck, ansosnten rufe
   * openIndex auf und erzeuge einen neuen Eintrag. Ggf. die Laenge der
   * Liste pruefen und wenn max_open_files (muesste im Konstrultor noch
   * uebergeben werden) erreicht ist, dann eine der Dateien schliessen
   * um Fehlermeldung des FileManagers zu vermeiden
   */

void ExecEngine::openFile(string & fileName,FileNo & fileNo)
{
  Str2FileNoType::iterator it = fileNoList.find(fileName);
  if(it!=fileNoList.end()){
    fileNo = (*it).second;
  }else{
    indexMgr->openIndex(fileName,fileNo);
    pair<string,int> val;
    val.first = fileName;
    val.second = fileNo;
    fileNoList.insert(val);
  }
}

  /*
   * Entfernt die Datei aus der Liste, wenn sie geoeffnet worden ist.
   * Offene Dateien muessen natuerlich zunaechst geschlossen werden
   */


void ExecEngine::closeFile(string & fileName)
{
  Str2FileNoType::iterator it = fileNoList.find(fileName);
  if(it!=fileNoList.end()){
    indexMgr->closeIndex((*it).second);
    fileNoList.erase(it);
  }
}

void ExecEngine::initFileList() {
  fileNoList.clear();
}

void ExecEngine::listTables()
{
  // Die Aktion ist nur moeglich, wenn eine Verindung zu einer Datenbank
  // existiert.
  if (_isConnected == false) {
    errorMsg(EXEC_NO_CONNECTION);
    return;
  }
  list<TableInfo> tableInfoList;
  sysCat.listTables(_directory,tableInfoList);
  cout << "Name\tBlockCount\tModTime" << endl;
  while(tableInfoList.begin()!=tableInfoList.end()){
    TableInfo & info = tableInfoList.front();
    cout << info.getTableName() << "\t" 
	 << info.getBlockCount() << "\t" 
	 << ctime(&info.getModificationTime());
    tableInfoList.pop_front();
  }
}
